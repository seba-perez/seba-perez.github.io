# Plantilla LaTeX para Trabajo de Titulación
## Licenciatura en Astrofísica con mención en Ciencia de Datos
### Universidad de Santiago de Chile (USACH)

% -------------------------------------------------
% Aviso sobre el uso de esta plantilla
%
% Esta plantilla LaTeX ha sido desarrollada como una aproximación
% para facilitar la preparación del Trabajo de Titulación de la
% Licenciatura en Astrofísica con mención en Ciencia de Datos de la
% Universidad de Santiago de Chile.
%
% La estructura y el formato del documento buscan seguir lo más
% fielmente posible las indicaciones establecidas en la Guía de
% Trabajos de Titulación y Graduación de la Biblioteca USACH.
%
% No obstante, esta plantilla se ofrece únicamente como herramienta
% de apoyo. El autor o autora del trabajo es responsable de revisar el
% manual oficial en detalle y verificar que el documento final cumpla
% con todos los requisitos formales exigidos por la Universidad, la
% Biblioteca y la Unidad Académica correspondiente.
%
% En caso de existir discrepancias entre esta plantilla y el manual
% oficial, prevalecen las disposiciones establecidas en el manual.
% -------------------------------------------------

El objetivo de esta plantilla es ofrecer una estructura clara y consistente que facilite la escritura del trabajo y mantenga un formato uniforme entre las distintas tesis.

---

## Estructura del proyecto

.
├── main.tex # Archivo principal del documento
├── usachthesis.sty # Estilo y configuración general de la tesis
├── bibliografia.bib # Archivo BibTeX para las referencias
│
├── capitulos/ # Archivos de capítulos
│ ├── Resumen.tex
│ ├── cap1.tex
│ ├── cap2.tex
│ └── ...
│
└── figuras/ # Figuras y gráficos utilizados en el documento

---

## Uso básico

1. Editar el archivo 'main.tex' para completar los datos del trabajo:

- Título
- Autor/a
- Profesor(es) guía
- Año
- Proyecto financiado (si corresponde)

2. Escribir el contenido de cada capítulo en los archivos dentro de la carpeta:

capitulos/

3. Insertar los capítulos en 'main.tex' usando:

\include{capitulos/cap1}

Agregar las referencias bibliográficas en:

bibliografia.bib

y citarlas en el texto usando \citep{}, \citet{} o \cite{}.